 <?php

$mail='info@laplace.edu.gt';

 
$nombre = $_POST['nombre'];
$email = $_POST['email'];
$msg = $_POST['msg'];

$thank="index.html";

$message = "nombre: ".$nombre." email: ".$email." Mensaje: ".$msg."";
  
  if (mail($mail,"consulta",$message)) 
//       Header ("Location: $thank");
echo '"<script language="javascript">window.location="index.html"</script>;"'
  
 ?> 